import UIKit

var greeting = "Hello, playground"

print("Hello Varun",10,12.25)//comma seperated gives a space in the output
//STRING INTERPOLATION
// \(variableName) within the parenthesis
var name="Varun"
var grade=90.54

print("Hello, \(name)! Your grade is \(grade)")

var str="swift"

print("I LIKE THE \(str) PROGARMMING LANGUAGE")

var age=23

print("You are \(age) years old and in another \(age) years you will be \(age*2)")

//Mutiple paranthesis for block of print statements
print("""
Hekko woetrld
njdsdkj
kdjcds;
ncdkc
""")


// \r carriage return
print("Hello All, \rWoleocne to shift")

print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator :":-" )
print("Spring 2022")

print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is", terminator: "-")
print(1,2,3,4,5,6, separator: "#")

let  welcomeMessage : String = "Hello!"
   print(welcomeMessage , "All")


// worksheet 2
let cst=56
//Cannot assign to value: 'cst' is a 'let' constant
//cst=45
print(cst)

var mobileBrand = "Apple"
//let mobileBrand = "Samsung" Invalid redeclaration of 'mobileBrand'
mobileBrand = "Samsung"
print(mobileBrand)

var age1 : Int = 23
// age1 = age1 * 23.4 Cannot convert value of type 'Double' to expected argument type 'Int'
age1 = age1 * 23
print(age1)

var aweMessage = "This is Superb!"
print(aweMessage)
//print("aweMessage -" +aweMessage)
//print(aweMessage+aweMessage)
//print(aweMessage,"\(aweMessage)")
//print("hello"+aweMessage+"!")


var course1 = "iOS"
var course2 = "Java"
print(course1,course2)
print(course1,"-",course2)

print(10,20,30)
print(12.5,15.5)

var httpError  = (errorCode : 404  , errorMessage : "Page Not Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )
//print(httpError.errorCode+httpError.errorMessage)//overloads for '+' exist with these partially matching parameter lists: (Int, Int), (String, String)

var name1 = ("John","Smith")
var fName = name1.0
var lName = name1.1
print(fName , terminator : ",")
print(lName)
print(fName+","+lName)

var origin = (x : 0 , y : 0.00)
var point = origin
print(point)
print(point.x)
print(point.y)

let city = (name : "Maryville" , population : 11000)
let ( cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation+34)

let groceries = ("bread","onions",34.5)
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

var fname = "Joe"
var lname = "Root"
(fname , lname) = (lname , fname)
print("First Name is \(fname) and Last Name is \(lname)")

var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
